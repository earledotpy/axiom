# Claude Upload List

Upload these files to the Claude Project knowledge base:

1. common_uploads/AXIOM_00_Project_Primer.md
2. common_uploads/AXIOM_01_Governance_Boundary_Map.md
3. common_uploads/AXIOM_02_Level_2A_Control_Model.md
4. common_uploads/AXIOM_03_Implementation_Mandate_Template.json
5. common_uploads/AXIOM_04_Review_Response_Format.md
6. common_uploads/AXIOM_05_Decision_Log_Template.md
7. common_uploads/AXIOM_06_Web_Chat_Operating_Rules.md
8. common_uploads/AXIOM_07_Current_Working_Context.md
9. common_uploads/AXIOM_08_Web_Chat_Role_Map.md
10. common_uploads/AXIOM_Final_v4_1a_Proposal_and_Operators_Guide.md

Use the project instructions from Claude_Project_Instructions.txt.
Use the summary from Claude_Project_Summary.md.
