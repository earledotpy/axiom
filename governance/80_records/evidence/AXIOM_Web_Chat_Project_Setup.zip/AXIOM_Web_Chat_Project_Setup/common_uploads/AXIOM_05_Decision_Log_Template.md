# AXIOM Decision Log Template

## Decision ID

DK-YYYY-NNNN

## Date

YYYY-MM-DD

## Decision Title

Short name.

## Current Status

Choose one:

- proposed
- under_review
- approved_for_mandate_drafting
- rejected
- deferred
- implemented
- verified
- closed

## Governance Question

What is being decided?

## Context

Relevant background.

## Options Considered

### Option A

Pros:
Cons:
Risks:

### Option B

Pros:
Cons:
Risks:

## Review Inputs

### ChatGPT

Summary:

### Claude

Summary:

### Gemini

Summary:

## Operator Decision

Jeremy’s decision.

## Authority Impact

Does this expand authority?

- no
- yes, requires Mandate
- yes, requires doctrine review
- yes, Level 2B or later only

## Implementation Mandate Needed?

- yes
- no

## Required Tests

List.

## Final Disposition

Outcome.
