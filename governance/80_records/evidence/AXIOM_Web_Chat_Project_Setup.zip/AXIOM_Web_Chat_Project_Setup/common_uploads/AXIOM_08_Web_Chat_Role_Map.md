# AXIOM Web Chat Role Map

## Jeremy

Governance Principal, Operator, Capability Authority, source of governing intent.

## ChatGPT Web Project

Role: Governance synthesis and mandate drafting.

Best use:
- consolidate Claude/Gemini feedback;
- structure decisions;
- draft operator-facing documents;
- generate implementation mandate candidates;
- identify unresolved assumptions.

Do not use for:
- direct execution authority;
- replacing signed Mandates.

## Claude Web Project

Role: invariant, threat-model, and enforcement review.

Best use:
- identify contradictions;
- test safety invariants;
- distinguish prevention from detection;
- specify negative tests;
- find authority leaks;
- critique overclaims.

Do not use for:
- owning governance doctrine;
- granting authority.

## Gemini Gem

Role: systems architecture, scalability, and transferability review.

Best use:
- evaluate architecture boundaries;
- reduce over-engineering;
- assess constrained hardware feasibility;
- test portability to stronger hardware/cloud/containerized future;
- identify orchestration complexity risks.

Do not use for:
- direct implementation authority;
- replacing Orchestrator gates.
