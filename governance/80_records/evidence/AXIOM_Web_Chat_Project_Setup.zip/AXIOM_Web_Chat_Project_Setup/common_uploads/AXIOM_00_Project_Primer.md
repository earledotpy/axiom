# AXIOM Project Primer

## Project Purpose

AXIOM is an operator-governed, local-first, fail-closed, autonomy-gated multi-agent system being built with AI agent assistance.

The project began as a test of whether independent LLM chatbots could collaboratively design scaffolding for an autonomous multi-agent system on constrained hardware. It later moved into CLI-based implementation using Claude Code, Codex, and Antigravity. That move created a control-plane drift problem: CLI relay and IPC behavior began to carry operational authority before the governance substrate was ready.

## Current Correction

AXIOM is now moving toward Level 2A:

**Level 2A — Verifier-Isolated Operator-Authorized Implementation**

Level 2A introduces:

- deterministic Orchestrator hub;
- execution-free typed artifact Relay;
- signing-only Operator Console;
- Ed25519 signed Implementation Mandates;
- restricted Windows verifier account;
- verifier-owned Python environment;
- pinned trusted-test hashes;
- restricted test collection;
- static AST/source risk scanning;
- append-only audit;
- no live doctrine swap until tests pass.

## Current Live Doctrine

The live doctrine remains:

```text
non-autonomous by design
```

The target doctrine after Level 2A tests pass is:

```text
operator-governed, fail-closed, autonomy-gated, scalable, transferable, and AI-built
```

## Human Authority

Jeremy is the Governance Principal, Operator, Capability Authority, and source of governing intent.

No AI agent owns the governing intent.

## Web Chat Role

Web chat projects are used for Orchestration Governance: reasoning, review, doctrine, proposal development, and decision support.

Web chat outputs are advisory until converted into a signed Implementation Mandate.

## CLI Role

CLI agents are used for Operational Governance: implementation, diff production, testing, verification, and evidence generation within mandate scope.

## Critical Rule

No chat message, markdown note, CLI prompt, agent reply, or relay packet carries operational authority by itself.

Only a signed Implementation Mandate accepted by the Orchestrator carries authority.
