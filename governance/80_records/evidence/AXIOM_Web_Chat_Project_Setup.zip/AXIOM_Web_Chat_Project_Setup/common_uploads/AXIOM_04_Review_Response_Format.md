# AXIOM Review Response Format

Use this format when reviewing AXIOM proposals, mandates, or implementation plans.

## Executive Verdict

Choose one:

- Approve
- Approve after changes
- Reject

State the reason in one paragraph.

## Blocking Objections

List only issues that prevent implementation or ratification.

For each:
- identifier
- affected invariant
- risk
- required correction

## Non-Blocking Concerns

List issues that should be tracked but do not block the next step.

## Required Schema Changes

Identify required changes to Mandates, dockets, relay envelopes, audit records, or summaries.

## Required Tests

List negative and positive tests. Prefer concrete test names.

## Required Implementation Changes

List exact files, modules, scripts, tools, or workflows that should change.

## Machine-Enforced vs Documented

Separate:
- what must be enforced by code, OS permissions, signatures, or hooks;
- what can remain an instruction or operating norm.

## Go / No-Go Recommendation

State whether the artifact is ready for:
- further web chat discussion;
- CLI implementation;
- live-spine update;
- doctrine change.
