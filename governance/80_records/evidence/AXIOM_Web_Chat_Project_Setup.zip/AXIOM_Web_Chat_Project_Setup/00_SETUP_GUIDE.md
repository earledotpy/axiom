# AXIOM Web Chat Project Setup Guide

This package creates the Orchestration Governance layer for AXIOM across:

- ChatGPT Project
- Claude Project
- Gemini custom Gem

## Official Setup Notes

ChatGPT Projects support project names, uploaded source files, and project-specific instructions. Project instructions apply inside the project and override global custom instructions. ChatGPT Projects also maintain project memory across chats and files.

Claude Projects provide self-contained workspaces with their own chat histories and knowledge bases. Claude lets you upload project knowledge and set project instructions that apply across chats inside the project.

Gemini’s closest equivalent is a custom Gem. Gemini Gems support names, instructions, previewing/saving the Gem, and uploading files under Knowledge.

## Project Names

### ChatGPT

AXIOM Governance — Synthesis & Mandates

### Claude

AXIOM Governance — Invariant & Threat Review

### Gemini

AXIOM Governance — Architecture & Scale

## Setup Order

1. Create the ChatGPT Project.
2. Add ChatGPT_Project_Instructions.txt as the project instructions.
3. Upload the files listed in ChatGPT_Upload_List.md.

4. Create the Claude Project.
5. Add Claude_Project_Instructions.txt as the project instructions.
6. Upload the files listed in Claude_Upload_List.md.

7. Create the Gemini custom Gem.
8. Add Gemini_Gem_Instructions.txt as the Gem instructions.
9. Upload the files listed in Gemini_Gem_Upload_List.md under Knowledge.
10. Save the Gem.

## Operating Rule

The web chat layer is advisory.

Do not treat a web chat answer as operational authority.

Only a signed Implementation Mandate accepted by the Orchestrator carries authority.

## Security Rule

Do not upload:

- private signing keys;
- API keys;
- local passwords;
- `.env` files;
- live reusable signed Mandates;
- unredacted secrets;
- personal system secrets;
- local credential files.

## First Prompt to Use in Each Project

Use this after setup:

```text
Read the uploaded AXIOM project sources and summarize your assigned role in this project.

Do not re-litigate the broad AXIOM doctrine.

Confirm:
1. what your project role is;
2. what you are not authorized to do;
3. how you should review AXIOM artifacts;
4. what files in project knowledge are most important;
5. what question I should ask you first when beginning Level 2A implementation.
```
