# AXIOM Final Draft v4.1a — Level 2A Verifier Beachhead, Control-Plane Correction, and Operator Guide

**Prepared for:** Jeremy Earle, AXIOM Operator  
**Document type:** Final pre-implementation proposal + operator runbook  
**Target level:** Level 2A — Verifier-Isolated Operator-Authorized Implementation  
**Doctrine status:** Live doctrine remains **non-autonomous by design** until Level 2A substrate tests pass  
**Target doctrine after tests:** **operator-governed, fail-closed, autonomy-gated, scalable, transferable, and AI-built**

---

# Part I — Final Proposal v4.1a

## 1. Executive Summary

AXIOM is being corrected from an improvised CLI relay/governance system into a controlled Level 2A implementation architecture.

The project originally used web chat interfaces for high-level multi-model governance and Claude Code/Codex/Antigravity CLI surfaces for live implementation. The transition to CLI created a split-brain control-plane problem: the formal AXIOM runtime had manifest/posture gates, while the IPC/CLI layer could route prompts or execution outside those gates.

Proposal v4.1a resolves this by introducing:

1. a deterministic Orchestrator hub;
2. an execution-free Relay channel;
3. a signing-only Operator Console channel;
4. Ed25519 signed Implementation Mandates;
5. a restricted Windows verifier account;
6. a verifier-owned Python environment;
7. pinned trusted-test hashes;
8. restricted pytest collection;
9. static AST/source risk scanning before tests;
10. append-only audit;
11. a strict rule that web chat outputs are advisory until converted into a signed Mandate.

The immediate target is not full autonomous operation. The immediate target is to make Level 2A implementation safe enough to proceed toward autonomy-gated doctrine later.

---

## 2. Settled Constraints

These are no longer open design questions.

1. Claude Code, Codex, and Antigravity currently run under Jeremy’s normal Windows user account.
2. A second Windows account can be created now.
3. The Remote Operator Console signs only; it does not execute.
4. The Orchestrator executes or denies operational work.
5. Builder-modified tests are untrusted.
6. Trusted tests are trusted inputs only; they do not make imported code trusted.
7. Web chat projects remain in use for Orchestration Governance.
8. Web chat projects do not carry machine authority.
9. The live spine remains **non-autonomous by design** until Level 2A tests pass.
10. Level 2A is the immediate implementation target.
11. Level 2B is the later hardening target.

---

## 3. Core Architecture

## 3.1 Two Channels

### Relay Channel

**Path:** CLI agents ↔ Orchestrator  
**Purpose:** Move typed artifacts only.  
**Examples:** patch artifact, review artifact, audit event, verification report, dead-letter event.  
**Forbidden:** shell command, direct agent invocation, peer-to-peer prompt relay, recursive reply chain.

The Relay is hub-and-spoke only:

```text
Claude Code  ─┐
Codex        ─┼──> Orchestrator ──> authorized next step
Antigravity  ─┘
```

No agent sends directly to another agent.

### Console Channel

**Path:** Operator ↔ Orchestrator  
**Purpose:** Operator review, signing, pause/resume, denial, status visibility.  
**Forbidden:** direct shell execution, direct agent invocation, remote general-purpose terminal.

The Console produces signed Mandates or signed state-change requests. It never runs the work.

---

## 3.2 Two Functions

### Orchestration Governance

**Surfaces:**

- ChatGPT web project
- Claude web project
- Gemini web project

**Role:**

- doctrine discussion;
- architectural reasoning;
- capability-level decisions;
- cross-model critique;
- proposal review;
- implementation mandate drafting.

**Authority:** none by itself.

A web chat decision is not operationally binding until Jeremy converts it into a signed Implementation Mandate.

### Operational Governance

**Surfaces:**

- deterministic Orchestrator;
- Claude Code;
- Codex;
- Antigravity;
- restricted verifier account;
- mandate store;
- audit store;
- verification worktrees.

**Role:**

- consume signed Mandates;
- invoke scoped agent work;
- verify artifacts;
- run constrained tests;
- record audit evidence;
- transition docket state.

**Authority:** only through signed Mandates and Orchestrator gates.

---

## 3.3 One Enforcement Core

The deterministic Orchestrator owns:

- gate calls;
- relay ingress;
- mandate validation;
- nonce consumption;
- docket state transitions;
- audit logging;
- artifact hash binding;
- verifier-account execution;
- trusted-test validation;
- `VERIFIED_COMMIT` / `AUDIT_FAILED` decisions.

The Orchestrator is not an LLM.

---

## 3.4 One Authority-Bearing Bridge

The only authority-bearing bridge from Orchestration Governance to Operational Governance is the signed Implementation Mandate.

No chat message, markdown note, agent assertion, relay packet, or CLI prompt carries authority by itself.

---

## 4. Level 2A Definition

## 4.1 Name

**Level 2A — Verifier-Isolated Operator-Authorized Implementation**

## 4.2 What Level 2A Guarantees

Level 2A guarantees that governed AXIOM work:

1. requires a signed Implementation Mandate;
2. is mediated by the Orchestrator;
3. cannot be triggered by peer-to-peer agent messages;
4. cannot be triggered by raw IPC command frames;
5. cannot be triggered directly by the Console;
6. verifies Mandate signatures over canonical scope;
7. pins trusted tests by content hash;
8. treats Builder-modified tests as untrusted;
9. verifies through the restricted verifier account;
10. records deterministic audit evidence;
11. rejects or dead-letters out-of-scope, unsigned, stale, or tampered inputs.

## 4.3 What Level 2A Does Not Guarantee

Level 2A does not fully prevent:

1. an agent with shell access from taking direct action outside AXIOM’s governed path;
2. direct manual invocation of a CLI harness outside the Orchestrator;
3. all filesystem mutation by agents running under Jeremy’s normal account;
4. all possible Python import-time side effects;
5. full containment of untrusted code;
6. full OS-level separation of all agents.

Those are Level 2B or later concerns.

## 4.4 Level 2A Honesty Rule

`VERIFIED_COMMIT` is valid only if issued by the Orchestrator through the restricted verifier-account path.

If verification is run under Jeremy’s normal account, the terminal state must degrade to one of:

```text
VERIFIED_EVIDENCE_RECORDED
AUDIT_ACCEPTED_PENDING_2B
```

`VERIFIED_COMMIT` means:

1. the signed Mandate was valid;
2. the authorized artifact hash matched;
3. trusted test files matched pinned hashes;
4. verification ran under the restricted verifier path;
5. the verifier execution environment was controlled;
6. required checks passed;
7. the Orchestrator recorded the result.

It does **not** mean the code under test was inherently trusted. It means the verification happened inside the approved Level 2A containment boundary.

---

## 5. Restricted Verifier Account

## 5.1 Account

Recommended account name:

```text
axiom_verifier
```

## 5.2 Purpose

The restricted verifier account is the first Level 2A prevention beachhead.

It exists to protect:

- mandate verification;
- audit state;
- verifier worktrees;
- trusted-test execution;
- final docket transition authority.

## 5.3 Protected State Root

Recommended root:

```text
C:\axiom_state\
```

Use platform abstraction in schemas:

```text
$AXIOM_STATE_ROOT
$AXIOM_WORKSPACE
```

Do not sign hardcoded `C:\...` paths into portable Mandates unless the field is explicitly host-local.

## 5.4 Directory Layout

```text
$AXIOM_STATE_ROOT\
  mandates\
  audit\
  relay\
  relay_dead_letter\
  verifier_worktrees\
  verifier_venv\
  public_keys\
  artifact_store\
  sqlite\
```

The normal project repository remains:

```text
$AXIOM_WORKSPACE\
```

On the current workstation this is expected to resolve to:

```text
C:\axiom
```

## 5.5 Python Environment Isolation

The verifier account must use its own virtual environment:

```text
$AXIOM_STATE_ROOT\verifier_venv\
```

This environment must not be writable by the normal agent-running account during normal operation.

The verifier must not use:

- a shared global Python environment;
- writable shared site-packages;
- a normal operator-account venv;
- arbitrary inherited `PYTHONPATH`.

## 5.6 Network and Environment Policy

During verifier test execution:

- network is disabled where feasible;
- environment variables are pruned;
- no agent secrets are inherited;
- no operator private signing key is present;
- only minimal required variables are allowed.

Minimum environment allowlist:

```text
PATH
PYTHONPATH only if set to verifier-controlled paths
AXIOM_WORKSPACE
AXIOM_STATE_ROOT
TEMP/TMP if needed, pointing to verifier-controlled temp
```

---

## 6. Implementation Mandate

## 6.1 Mandate Principles

An Implementation Mandate is:

- JSON;
- Ed25519 signed;
- canonicalized;
- nonce-bearing;
- expiration-bound;
- single-use;
- scope-bound;
- artifact-bound;
- workspace-relative;
- verified before operational use.

## 6.2 No HMAC Fallback

HMAC fallback is removed.

Reason: HMAC requires the verifier to hold the same secret that signs. In a workstation where agent harnesses currently run under the normal operator account, this increases authority-leak risk.

Use Ed25519 from day one.

- Console/local signing utility holds the private key.
- Orchestrator/verifier holds only the public key.

## 6.3 Private Key Handling

For Level 2A:

- do not store the unencrypted private key in the repository;
- do not store the unencrypted private key under `$AXIOM_STATE_ROOT`;
- do not leave the private key mounted/accessible while agents are running;
- use a passphrase-protected private key;
- pause agent CLIs before signing Mandates;
- consider removable storage or hardware-backed key later.

The signing step is intentionally manual at Level 2A.

## 6.4 Canonicalization

Use a pinned canonicalization algorithm.

Recommended:

```text
RFC 8785 JSON Canonicalization Scheme (JCS)
```

If RFC 8785 is not used, AXIOM must define a deterministic canonical JSON format and test it.

## 6.5 Mandate Schema

```json
{
  "manifest_version": "1.0.0",
  "mandate_id": "MND-2026-0001",
  "docket_id": "DK-2026-0007",
  "parent_mandate_id": null,

  "governance_record_hash": "sha256:<approved-governance-record-hash>",
  "authorized_artifact_sha256": "sha256:<approved-patch-or-task-artifact-hash>",

  "scope_context_hashes": [
    {
      "path": "ipc/",
      "sha256": "sha256:<targeted-context-hash>"
    }
  ],

  "target_level": "2A",
  "intent": "Neutralize raw IPC command execution and route relay frames through the Orchestrator.",

  "execution_scope": {
    "workspace_root_token": "$AXIOM_WORKSPACE",
    "state_root_token": "$AXIOM_STATE_ROOT",
    "allowed_write_paths": [
      "ipc/",
      "tests/ipc/"
    ],
    "blocked_paths": [
      "governance/",
      "tools/seal.py",
      "tools/gatekeeper.py",
      "$AXIOM_STATE_ROOT/"
    ],
    "blocked_path_policy": "blocked_paths_always_win_reject_allowed_ancestor_at_level_2A"
  },

  "verification_env": {
    "venv_ref": "$AXIOM_STATE_ROOT/verifier_venv",
    "network": false,
    "environment_policy": "minimal_allowlist",
    "pythonpath_policy": "pruned_verifier_worktree_only"
  },

  "allowed_commands": [
    {
      "executable": "python",
      "args": ["-m", "pytest", "tests/ipc/test_relay.py", "-v"],
      "shell": false
    }
  ],

  "required_tests": [
    {
      "path": "tests/ipc/test_relay.py",
      "content_sha256": "sha256:<trusted-test-content-hash>",
      "trust_level": "trusted_pinned"
    }
  ],

  "test_policy": {
    "builder_modified_tests_are_untrusted": true,
    "trusted_tests_must_match_content_hash": true,
    "trusted_test_collection_must_be_explicit": true,
    "broad_directory_collection_disallowed": true,
    "pre_test_ast_scan_required": true
  },

  "budget": {
    "max_runtime_seconds": 300,
    "max_token_expenditure_usd": 1.50,
    "budget_enforcement": "advisory_until_meter_exists"
  },

  "validity": {
    "issued_at": "2026-05-31T12:00:00-06:00",
    "expires_at": "2026-05-31T14:00:00-06:00",
    "nonce": "<random-128-bit-or-better-nonce>",
    "single_use": true
  },

  "operator_identity": {
    "operator_id": "jeremy",
    "signing_key_id": "jeremy_ed25519_001"
  },

  "cryptographic_seal": {
    "algorithm": "Ed25519",
    "canonicalization": "RFC8785-JCS",
    "signed_fields": [
      "manifest_version",
      "mandate_id",
      "docket_id",
      "parent_mandate_id",
      "governance_record_hash",
      "authorized_artifact_sha256",
      "scope_context_hashes",
      "target_level",
      "intent",
      "execution_scope",
      "verification_env",
      "allowed_commands",
      "required_tests",
      "test_policy",
      "budget",
      "validity",
      "operator_identity"
    ],
    "signature": "<ed25519-signature-over-canonicalized-signed-fields>"
  }
}
```

## 6.6 Artifact Hash Binding

Approving a scope is not enough.

The Mandate must authorize a specific artifact hash when work is ready to be applied.

If the patch artifact is not known when the first Mandate is signed, then `OPERATOR_GATE` must produce a second signed approval over the exact artifact hash before the Orchestrator applies it.

## 6.7 Path Precedence

Blocked paths always win.

At Level 2A, reject any Mandate where an allowed path is an ancestor of a blocked path.

Do not implement complex carve-out logic yet.

---

## 7. Gate Service

## 7.1 Existing Gate

AXIOM already has a runtime gate. Do not build a second competing AutonomyGate.

Expose or wrap the existing runtime gate for Orchestrator use.

## 7.2 Cache Rule

`posture_cache.json` is display-only.

Execution enforcement must call the gate function/service.

If a cache fallback is ever used:

- stale cache denies;
- missing cache denies;
- malformed cache denies;
- `overall_ready=false` denies.

## 7.3 Required Gate Client Shape

```python
assert_gate_allows(action_class: str, scope: dict, route: str) -> None
```

Deny cases:

- gate call error;
- gate timeout;
- gate not-ready;
- route disallowed at current level;
- missing Mandate;
- invalid Mandate;
- expired Mandate;
- reused nonce;
- artifact hash mismatch;
- out-of-scope path;
- blocked-path overlap;
- direct Console execution;
- peer-to-peer execution.

---

## 8. Relay and Ingress

## 8.1 Relay Rule

The Relay cannot execute.

It only submits typed artifacts to Orchestrator ingress.

## 8.2 SQLite WAL Ingress

For Level 2A, prefer SQLite WAL over raw file-drop relay inboxes.

Recommended path:

```text
$AXIOM_STATE_ROOT\sqlite\relay_queue.db
```

Rationale:

- local-first;
- lightweight;
- durable;
- already compatible with AXIOM’s SQLite orientation;
- better than multiple filesystem watchers;
- easier to audit than ad hoc markdown inbox files.

## 8.3 Ingress Protection

Agents submit artifacts through a narrow ingress tool.

Agents must not directly write:

- docket state;
- mandate state;
- consumed nonce state;
- audit truth state;
- verifier worktrees.

## 8.4 Envelope Type Enum

Allowed types:

```text
review_request
architecture_artifact
patch_artifact
verification_report
audit_event
operator_summary_event
dead_letter_event
```

No `command` type exists for agents.

---

## 9. Console

## 9.1 Console Function

The Console may:

- display state;
- display deterministic telemetry;
- create signed Mandates;
- create signed pause/resume/deny requests.

The Console may not:

- run shell commands;
- invoke agents;
- execute deferred commands;
- act as a general remote terminal;
- bypass the Orchestrator.

## 9.2 Key Revocation Scope

Level 2A excludes remote key rotation/reissue.

Key revocation and rotation remain manual and out-of-band for now.

This avoids making key management itself another premature control plane.

---

## 10. Verification Model

## 10.1 Trusted Tests Are Not Trusted Execution

A pinned trusted test proves only that the test file is unchanged.

It does not prove the code imported by the test is safe.

## 10.2 Import-Time Code Execution Risk

Python tests can execute code before assertions run through:

- imports;
- package `__init__.py`;
- `conftest.py`;
- pytest plugins;
- `sitecustomize.py`;
- `.pth` files;
- import hooks;
- global module initialization.

Therefore trusted-test execution must happen only after:

1. artifact hash verification;
2. scope validation;
3. trusted-test hash validation;
4. AST/source risk scanning;
5. verifier environment isolation;
6. restricted collection.

## 10.3 AST Source Risk Scan

Use Python’s `ast` module for baseline scanning of Python mutated files.

The scan is a tripwire, not a proof of safety.

High-risk findings cause:

```text
AUDIT_FAILED
```

or require a new Mandate with explicit authorization.

Risk constructs include:

- subprocess execution;
- shell execution;
- dynamic eval/exec;
- import-hook manipulation;
- network access;
- file writes outside scope;
- environment mutation;
- startup-file changes;
- pytest plugin changes;
- `sitecustomize.py`;
- `usercustomize.py`;
- `.pth` manipulation;
- suspicious package `__init__.py` changes.

## 10.4 Restricted Pytest Collection

Trusted verification must run explicit pinned test files or node IDs.

Forbidden at Level 2A:

```text
python -m pytest tests/
python -m pytest tests/ipc/
```

Allowed:

```text
python -m pytest tests/ipc/test_relay.py::test_command_type_rejected -v
python -m pytest tests/ipc/test_relay.py tests/ipc/test_gate_client.py -v
```

## 10.5 Verifier Environment

The verifier run must use:

- verifier-owned venv;
- pruned worktree;
- minimal environment;
- no shared writable site-packages;
- no broad `PYTHONPATH`;
- no inherited agent process state;
- no network where feasible.

---

## 11. Docket States

Level 2A states:

```text
INTAKE
PANEL_REVIEW
OPERATOR_GATE
IMPLEMENTATION_IN_PROGRESS
VERIFICATION_PENDING
AUDIT_FAILED
VERIFIED_COMMIT
CLOSED
```

State rules:

- only Orchestrator-authored transitions are recognized;
- agent-authored state writes are invalid;
- direct state tampering is audit evidence;
- `AUDIT_FAILED` consumes or strips temporary authorization atomically;
- `VERIFIED_COMMIT` requires verifier-account evidence.

---

## 12. Audit and Telemetry

## 12.1 Audit Log

The audit log is append-only and hash-chained.

Events include:

- mandate issued;
- mandate verified;
- mandate rejected;
- artifact hash recorded;
- artifact hash mismatch;
- nonce consumed;
- gate denied;
- relay dead-letter;
- static risk scan failed;
- trusted-test hash mismatch;
- verification started;
- verification failed;
- verification completed;
- state tampering detected.

## 12.2 Deterministic Operator Summaries

Operator summaries for critical events must be deterministic and generated from structured fields.

Example:

```text
EVENT: audit_failed
DOCKET: DK-2026-0007
MANDATE: MND-2026-0001
REASON: trusted_test_hash_mismatch
AFFECTED_PATH: tests/ipc/test_relay.py
NEXT_ALLOWED_ACTIONS:
  - operator_review
  - revise_mandate
  - close_docket
```

LLM commentary must be separately labeled:

```text
untrusted_agent_commentary
```

It must never be rendered as the audit summary.

---

## 13. Implementation Sequence

## Phase 0 — Baseline and Freeze

Goal: document current state and prevent further uncontrolled drift.

Actions:

1. Record current branch and git status.
2. Export current IPC scripts.
3. Record current startup scripts.
4. Record whether auto-injection was known experimental config or emergent governance incident.
5. Freeze peer-to-peer prompt routing.
6. Freeze raw command execution paths.
7. Do not alter live doctrine yet.

## Phase 1 — Verifier Account and State Root

Goal: establish the Level 2A prevention beachhead.

Actions:

1. Create `axiom_verifier`.
2. Create `$AXIOM_STATE_ROOT`.
3. Create protected subdirectories.
4. Create verifier-owned venv.
5. Grant verifier read access to workspace as needed.
6. Do not run agent CLIs under `axiom_verifier`.

## Phase 2 — Neutralize Raw Execution

Goal: remove current unsafe IPC execution paths.

Actions:

1. remove or gate `Invoke-Expression`;
2. remove inbound Codex auto-invocation;
3. remove inbound Antigravity auto-invocation;
4. reject `command` frames;
5. add negative tests for shell-trigger attempts.

## Phase 3 — Mandate Sealing

Goal: make operator authority machine-verifiable.

Actions:

1. implement Ed25519 key generation/signing;
2. implement RFC 8785 or equivalent canonicalization;
3. implement Mandate validation;
4. enforce nonce, expiry, single-use;
5. reject tampered signed fields.

## Phase 4 — Orchestrator Hub and Relay Queue

Goal: replace peer routing with Orchestrator-mediated artifact routing.

Actions:

1. implement SQLite WAL relay queue;
2. implement typed envelope validation;
3. implement dead-letter handling;
4. implement deterministic summaries;
5. prohibit direct agent-to-agent edges.

## Phase 5 — Gate Wiring

Goal: bring IPC/CLI under runtime posture.

Actions:

1. wire Orchestrator to existing runtime gate;
2. fail closed on gate error;
3. treat `posture_cache.json` as display-only;
4. add stale-cache denial test.

## Phase 6 — Verification Hardening

Goal: make `VERIFIED_COMMIT` honest.

Actions:

1. verify authorized artifact hash;
2. create clean verifier worktree;
3. run AST/source risk scan;
4. verify pinned trusted-test hashes;
5. run restricted pytest collection;
6. run under verifier-owned venv;
7. run with pruned environment;
8. disable network where feasible;
9. emit `VERIFIED_COMMIT` or `AUDIT_FAILED`.

## Phase 7 — Audit and Doctrine Eligibility

Goal: prove the substrate before changing doctrine.

Actions:

1. run Level 2A acceptance suite;
2. verify audit chain;
3. verify failure cases;
4. verify `VERIFIED_COMMIT` cannot be emitted by normal account;
5. only then consider doctrine change.

---

## 14. Acceptance Tests

Minimum doctrine-eligibility tests:

1. command frame rejected.
2. `Invoke-Expression` unreachable.
3. inbound relay cannot spawn Codex.
4. inbound relay cannot spawn Antigravity.
5. peer-to-peer relay denied.
6. Console cannot execute.
7. unsigned Mandate rejected.
8. expired Mandate rejected.
9. reused nonce rejected.
10. tampered `allowed_write_paths` invalidates signature.
11. tampered `allowed_commands` invalidates signature.
12. JSON canonicalization stable under key reordering.
13. blocked path overrides allowed path.
14. allowed ancestor of blocked path rejected.
15. Orchestrator calls gate service, not cache.
16. stale cache denies.
17. gate error denies.
18. not-ready gate denies.
19. patch artifact swap rejected.
20. operator approval over one artifact cannot authorize another.
21. trusted test hash mismatch causes `AUDIT_FAILED`.
22. Builder-created test classified untrusted.
23. broad pytest directory collection rejected.
24. Builder-added `conftest.py` not collected in trusted run.
25. AST scan catches import-time side-effect pattern.
26. verifier runs with verifier-owned venv.
27. shared site-packages poisoning attempt fails.
28. verifier network egress attempt fails or is blocked.
29. verification under normal account cannot emit `VERIFIED_COMMIT`.
30. agent-written docket state rejected or ignored.
31. audit chain detects mutation.
32. LLM commentary cannot render as deterministic audit summary.
33. Auditor identity check uses signed artifact identity, not `from_agent` string.
34. `AUDIT_FAILED` consumes or strips temporary authorization atomically.
35. budget field is treated as advisory unless a meter exists.

---

## 15. Level 2B Future Hardening

Level 2B will add:

- separate OS principals for each agent;
- stronger ACL separation;
- restricted worktrees per agent;
- stronger sandboxing;
- no shared agent runspace;
- private network controls;
- stronger process isolation;
- hardware-backed signing if available;
- container or VM isolation when hardware permits.

Level 2B is not required before starting Level 2A.

---

# Part II — Operator Guide

This guide describes what Jeremy should do from the current state to Level 2A implementation.

---

## 16. Operator Rule Zero

Do not change the live doctrine yet.

The live spine remains:

```text
non-autonomous by design
```

The target doctrine remains:

```text
operator-governed, fail-closed, autonomy-gated, scalable, transferable, and AI-built
```

The doctrine changes only after Level 2A acceptance tests pass.

---

## 17. Operator Work Modes

You will use three work modes.

## 17.1 Web Chat Orchestration Mode

Use ChatGPT, Claude, and Gemini web projects for:

- proposal review;
- doctrine discussion;
- architectural critique;
- implementation strategy;
- mandate drafting;
- postmortem review.

Do not use web chat output as operational authority.

## 17.2 CLI Build Mode

Use Claude Code, Codex, and Antigravity for:

- repository inspection;
- implementation;
- test writing;
- diff review;
- local debugging.

Until Orchestrator/Relay are built, you will manually transfer prompts. Avoid letting any CLI auto-route to another CLI.

## 17.3 Verifier Mode

Use `axiom_verifier` only for:

- verifying Mandates;
- running trusted pinned tests;
- producing final audit evidence;
- issuing `VERIFIED_COMMIT` or `AUDIT_FAILED`.

Do not use `axiom_verifier` as a normal coding account.

---

## 18. Start-to-Finish Procedure

## Step 1 — Save the Current State

From your normal Windows account, open PowerShell in the AXIOM repo:

```powershell
Set-Location C:\axiom
git status
git branch
git log -1 --oneline
```

Create a branch for Level 2A work:

```powershell
git checkout -b axiom/level-2a-control-plane
```

Create a baseline folder:

```powershell
New-Item -ItemType Directory -Force C:\axiom\governance\07_level_2a_baseline | Out-Null
```

Copy current IPC scripts and startup files into baseline evidence:

```powershell
Copy-Item C:\axiom\ipc C:\axiom\governance\07_level_2a_baseline\ipc_snapshot -Recurse -Force
Copy-Item C:\axiom\*.md C:\axiom\governance\07_level_2a_baseline\root_md_snapshot -Force -ErrorAction SilentlyContinue
```

Record current status:

```powershell
git status | Out-File C:\axiom\governance\07_level_2a_baseline\git_status_before.txt
```

---

## Step 2 — Send Final v4.1a to Web Chat Projects

Upload this final document to:

- ChatGPT AXIOM project;
- Claude AXIOM project;
- Gemini AXIOM project.

Use this prompt:

```text
This is the final AXIOM v4.1a Level 2A implementation candidate.

Do not re-litigate the general AXIOM doctrine unless you find a specific implementation blocker.

Review only for:
1. fatal implementation risks;
2. missing acceptance tests;
3. incorrect Windows/verifier-account assumptions;
4. mandate schema defects;
5. verification containment gaps;
6. reasons this should not become the Level 2A implementation plan.

If you approve, say explicitly:
“Approve v4.1a as the Level 2A implementation plan, with no doctrine swap until tests pass.”

If you approve after changes, list only the required changes.

If you reject, identify the exact invariant that fails.
```

If no fatal blocker is returned, proceed to Step 3.

---

## Step 3 — Create the Restricted Windows Account

Open PowerShell as Administrator.

Create the account:

```powershell
$VerifierPassword = Read-Host "Enter password for axiom_verifier" -AsSecureString
New-LocalUser -Name "axiom_verifier" -Password $VerifierPassword -Description "AXIOM restricted verifier account"
```

Do not add this account to Administrators.

Create state root:

```powershell
New-Item -ItemType Directory -Force C:\axiom_state | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\mandates | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\audit | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\relay | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\relay_dead_letter | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\verifier_worktrees | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\verifier_venv | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\public_keys | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\artifact_store | Out-Null
New-Item -ItemType Directory -Force C:\axiom_state\sqlite | Out-Null
```

Set restrictive ACLs:

```powershell
icacls C:\axiom_state /inheritance:r
icacls C:\axiom_state /grant "axiom_verifier:(OI)(CI)F"
icacls C:\axiom_state /grant "SYSTEM:(OI)(CI)F"
icacls C:\axiom_state /grant "Administrators:(OI)(CI)F"
```

Do not grant your normal user account direct write access unless required for setup. If your normal user is an administrator, do not run agent CLIs elevated.

Grant verifier read access to the AXIOM workspace:

```powershell
icacls C:\axiom /grant "axiom_verifier:(OI)(CI)RX"
```

---

## Step 4 — Create the Verifier-Owned Python Environment

Run this from an elevated PowerShell or by launching PowerShell as `axiom_verifier`.

Option A: use credential prompt:

```powershell
Start-Process powershell.exe -Credential ".\axiom_verifier" -ArgumentList "-NoExit", "-Command", "py -m venv C:\axiom_state\verifier_venv"
```

Then install only required verification dependencies. If `requirements.txt` is safe and reviewed:

```powershell
Start-Process powershell.exe -Credential ".\axiom_verifier" -ArgumentList "-NoExit", "-Command", "C:\axiom_state\verifier_venv\Scripts\python.exe -m pip install -r C:\axiom\requirements.txt"
```

If you want a minimal initial environment:

```powershell
Start-Process powershell.exe -Credential ".\axiom_verifier" -ArgumentList "-NoExit", "-Command", "C:\axiom_state\verifier_venv\Scripts\python.exe -m pip install pytest cryptography"
```

After setup, verify permissions:

```powershell
icacls C:\axiom_state\verifier_venv
```

Normal agent workflows should not be able to write this environment.

---

## Step 5 — Create Operator Signing Key Material

This step should be done with agent CLIs closed or paused.

The private key must not be stored in the repo or in `C:\axiom_state`.

Recommended temporary location:

```text
C:\axiom_operator_keys\
```

Create it:

```powershell
New-Item -ItemType Directory -Force C:\axiom_operator_keys | Out-Null
```

Important:

- private key must be passphrase-protected;
- do not leave it mounted/accessible during agent runs if avoidable;
- do not commit it;
- do not copy it to `C:\axiom`;
- do not copy it to `C:\axiom_state`.

The public key may be copied to:

```text
C:\axiom_state\public_keys\
```

The exact key-generation command depends on the implementation of `tools/seal.py`. The required behavior is:

```text
tools/seal.py generate-key
tools/seal.py sign mandate.json
tools/seal.py export-public-key
```

Until `tools/seal.py` exists, this step is a design requirement, not a live command.

---

## Step 6 — Freeze Existing IPC Execution Behavior

Before asking agents to modify code, establish the first Mandate or manual instruction: Phase 0/1 only.

Phase 0 task:

```text
Baseline current IPC and startup behavior.
Do not add new autonomy.
Do not add new relay features.
Do not alter doctrine.
Identify raw execution and auto-invocation paths.
Prepare a patch plan to neutralize them.
```

Manual CLI instruction to Claude Code:

```text
You are reviewing AXIOM for Level 2A Phase 0 baseline only.

Do not implement new autonomy.
Do not modify governance doctrine.
Inspect IPC scripts, startup scripts, and CLI relay behavior.
Identify:
1. any Invoke-Expression path;
2. any inbound message path that auto-invokes Codex;
3. any inbound message path that auto-invokes Antigravity;
4. any command-type relay frame;
5. any peer-to-peer agent routing.

Produce a Phase 0 baseline report and a minimal Phase 1 neutralization plan.
```

Manual CLI instruction to Codex:

```text
You are not implementing yet.

Review the Phase 0 baseline target and identify the minimal code changes needed to:
1. remove or gate Invoke-Expression;
2. disable inbound auto-invocation to Codex and Antigravity;
3. reject command-type frames;
4. preserve logs/evidence;
5. add negative tests.

Return a scoped implementation plan only.
```

Manual CLI instruction to Antigravity:

```text
Review the Level 2A control-plane correction from a systems architecture perspective.

Do not implement.
Focus on whether Phase 0 and Phase 1 are scoped narrowly enough:
- baseline current IPC;
- neutralize raw execution;
- avoid building the full Orchestrator too early.

Return architectural objections only.
```

---

## Step 7 — Implement Phase 1 Neutralization

Once Phase 0 is understood, create the first implementation Mandate manually.

Phase 1 scope should include only:

- IPC scripts;
- tests for IPC command rejection;
- no Orchestrator;
- no doctrine change.

The first implementation task should not touch:

- governance live spine doctrine;
- model profiles;
- scheduler autonomy;
- network gateways;
- memory gateways;
- Telegram/operator control plane;
- cloud inference.

Codex implements. Claude verifies. Antigravity reviews architecture drift.

---

## Step 8 — Build the Mandate Tooling

After unsafe IPC execution is neutralized, build:

```text
tools/seal.py
tools/mandate_validator.py
tools/canonical_json.py
```

Minimum features:

- Ed25519 key support;
- RFC 8785 or deterministic canonical JSON;
- signed field validation;
- nonce validation;
- expiry validation;
- single-use tracking;
- tamper rejection.

Do not add HMAC fallback.

---

## Step 9 — Build the Orchestrator Hub

Only after Mandate validation exists, build the Orchestrator.

Initial Orchestrator features:

- reads relay queue;
- validates envelope type;
- rejects `command`;
- records dead-letter events;
- verifies Mandate;
- calls gate service;
- refuses direct agent-to-agent route;
- writes deterministic audit event.

Do not build:

- persistent warm agents;
- autonomous multi-round loops;
- remote UI;
- socket-based mobile Console;
- Level 3 deferred execution.

---

## Step 10 — Wire the Runtime Gate

Implement:

```text
gate_client.assert_gate_allows(action_class, scope, route)
```

Rules:

- call existing runtime gate;
- do not enforce from `posture_cache.json`;
- fail closed on error, timeout, not-ready, stale fallback;
- audit denials.

---

## Step 11 — Implement Verification Hardening

Build:

```text
tools/source_risk_scan.py
tools/verify_trusted_tests.py
tools/apply_artifact_to_worktree.py
tools/run_verifier_tests.py
```

Required behavior:

1. content-address artifact at ingest;
2. re-hash before apply;
3. create clean verifier worktree;
4. apply artifact;
5. validate scope;
6. run AST/source scan;
7. verify trusted-test hashes;
8. run explicit pinned tests;
9. use `axiom_verifier` venv;
10. use pruned environment;
11. write `AUDIT_FAILED` or `VERIFIED_COMMIT`.

---

## Step 12 — Run Acceptance Tests

Do not update doctrine until acceptance tests pass.

Minimum command shape:

```powershell
pytest tests -v
```

Expected additional focused groups:

```powershell
pytest tests/ipc -v
pytest tests/mandates -v
pytest tests/orchestrator -v
pytest tests/verifier -v
pytest tests/audit -v
```

Only after all Level 2A tests pass should the live spine be updated.

---

## Step 13 — Update Live Spine After Tests

Only after Level 2A substrate tests pass:

1. update live doctrine from:

```text
non-autonomous by design
```

to:

```text
operator-governed, fail-closed, autonomy-gated by design
```

2. explicitly state:

```text
Level 2A has been implemented.
Level 2B remains future hardening.
Runtime autonomy remains disabled unless separately authorized.
```

3. record test evidence.

4. record the Mandate ID that authorized the doctrine update.

---

# Part III — Operator Decision Checklist

Before beginning implementation:

```text
[ ] v4.1a shared with Claude and Gemini web projects.
[ ] No fatal blockers returned.
[ ] Git branch created.
[ ] Baseline snapshot saved.
[ ] axiom_verifier account created.
[ ] C:\axiom_state created.
[ ] ACLs applied.
[ ] verifier venv created.
[ ] private signing key plan chosen.
[ ] agent CLIs not running elevated.
[ ] live doctrine unchanged.
```

Before Phase 1 implementation:

```text
[ ] Phase 0 baseline report exists.
[ ] unsafe IPC paths identified.
[ ] first Mandate scope excludes doctrine changes.
[ ] Codex implementation scope is narrow.
[ ] Claude verification scope is narrow.
[ ] Antigravity review scope is architectural only.
```

Before doctrine swap:

```text
[ ] raw IPC execution neutralized.
[ ] Orchestrator hub exists.
[ ] Ed25519 Mandates validate.
[ ] gate service wired.
[ ] verifier account path works.
[ ] verifier venv is isolated.
[ ] trusted-test hashes enforced.
[ ] AST/source scan works.
[ ] artifact hash binding works.
[ ] append-only audit works.
[ ] Level 2A acceptance tests pass.
[ ] final review completed.
```

---

# Part IV — Final Operator Position

AXIOM v4.1a should proceed as the implementation candidate.

The next work is not more doctrine debate. The next work is controlled implementation:

1. freeze and baseline current IPC;
2. create verifier account;
3. neutralize raw execution;
4. build Mandate validation;
5. build Orchestrator hub;
6. wire gate;
7. harden verification;
8. pass Level 2A tests;
9. then update doctrine.

Until that sequence is complete, AXIOM remains:

```text
non-autonomous by design
```

The destination remains:

```text
operator-governed, fail-closed, autonomy-gated, scalable, transferable, and AI-built
```
