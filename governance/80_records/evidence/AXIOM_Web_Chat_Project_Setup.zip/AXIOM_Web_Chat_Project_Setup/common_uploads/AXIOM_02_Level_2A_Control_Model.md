# AXIOM Level 2A Control Model

## Level 2A Name

Verifier-Isolated Operator-Authorized Implementation

## Level 2A Adds

- restricted Windows verifier account: axiom_verifier
- protected state root: $AXIOM_STATE_ROOT
- verifier-owned Python virtual environment
- signed Ed25519 Implementation Mandates
- pinned trusted-test hashes
- explicit trusted-test collection
- AST/source risk scan before tests
- artifact hash binding
- append-only audit
- Orchestrator-mediated relay
- signing-only Console

## Level 2A Does Not Claim

Level 2A does not fully prevent:

- direct agent shell action outside AXIOM;
- manual CLI invocation outside the Orchestrator;
- all filesystem mutation by agents under Jeremy’s normal account;
- all Python import-time side effects;
- full sandboxing of untrusted code.

Those belong to Level 2B or later.

## VERIFIED_COMMIT Rule

VERIFIED_COMMIT is valid only if issued by the Orchestrator through the restricted verifier-account path.

If verification runs under Jeremy’s normal Windows account, the terminal state must degrade to:

- VERIFIED_EVIDENCE_RECORDED
- AUDIT_ACCEPTED_PENDING_2B

## Doctrine Rule

Do not change the live doctrine from “non-autonomous by design” until Level 2A acceptance tests pass.
