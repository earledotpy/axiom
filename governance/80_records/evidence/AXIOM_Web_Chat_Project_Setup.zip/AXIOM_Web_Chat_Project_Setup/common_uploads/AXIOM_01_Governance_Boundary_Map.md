# AXIOM Governance Boundary Map

## Two Channels

### Relay Channel

Agent surfaces communicate with the deterministic Orchestrator through typed artifacts.

Allowed:
- review_request
- architecture_artifact
- patch_artifact
- verification_report
- audit_event
- operator_summary_event
- dead_letter_event

Forbidden:
- raw shell commands
- direct agent-to-agent prompts
- peer-to-peer execution
- recursive reply loops
- unsigned authorization
- direct Console execution

### Console Channel

Jeremy communicates with the Orchestrator through a signing and status channel.

Allowed:
- view status
- sign Implementation Mandates
- sign pause/resume/deny requests
- review deterministic summaries

Forbidden:
- direct shell execution
- direct agent invocation
- remote general-purpose terminal behavior
- bypassing Orchestrator gates

## Two Functions

### Orchestration Governance

Done in web chat projects.

Purpose:
- doctrine discussion
- architecture review
- capability decisions
- proposal critique
- cross-model reasoning
- mandate candidate drafting

Authority:
- advisory only

### Operational Governance

Done through CLI agents and deterministic local tooling.

Purpose:
- scoped implementation
- patch artifact production
- verification
- test evidence
- audit recording

Authority:
- only through signed Mandates

## One Enforcement Core

The deterministic Orchestrator owns:
- gate calls
- relay ingress
- mandate validation
- nonce consumption
- docket transitions
- audit logging
- artifact hash binding
- verifier-account execution
- VERIFIED_COMMIT / AUDIT_FAILED decisions

## One Authority-Bearing Bridge

The signed Implementation Mandate is the only bridge from governance reasoning to operational execution.
