# AXIOM Web Chat Operating Rules

## Core Rule

Web chat projects are Orchestration Governance spaces. They do not carry machine authority.

## Use Web Chat For

- doctrine discussion;
- proposal review;
- architecture critique;
- cross-model disagreement;
- decision memo drafting;
- implementation mandate drafting;
- postmortems.

## Do Not Use Web Chat For

- direct execution;
- raw commands to CLI agents;
- secrets or private keys;
- live API tokens;
- local passwords;
- unredacted environment files;
- final authority claims without an Implementation Mandate.

## Web Chat Output Status

All web chat outputs are advisory until Jeremy converts them into a signed Implementation Mandate.

## Prompt Discipline

Ask models to:
- identify blockers;
- separate machine enforcement from instructions;
- specify tests;
- avoid broad validation;
- avoid re-litigating settled doctrine unless a blocker is found.

## File Hygiene

Upload:
- proposal drafts;
- summaries;
- templates;
- sanitized logs;
- source snippets.

Do not upload:
- private keys;
- API tokens;
- passwords;
- signed live Mandates with reusable authority;
- local secrets;
- confidential personal information not required for the review.
