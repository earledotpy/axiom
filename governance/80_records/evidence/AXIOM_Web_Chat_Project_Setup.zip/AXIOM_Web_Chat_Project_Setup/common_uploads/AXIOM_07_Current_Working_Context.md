# AXIOM Current Working Context

## Current Goal

Design the web chat Orchestration Governance projects for ChatGPT, Claude, and Gemini, then use them to support Level 2A implementation.

## Current Implementation Target

AXIOM Final v4.1a.

## Immediate Work Sequence

1. Configure web chat projects/Gem.
2. Upload common source files.
3. Use web chat for review and mandate drafting only.
4. Create restricted Windows account: axiom_verifier.
5. Create state root: $AXIOM_STATE_ROOT.
6. Baseline and freeze unsafe IPC paths.
7. Neutralize raw execution.
8. Build Ed25519 Mandate tooling.
9. Build deterministic Orchestrator.
10. Wire existing runtime gate.
11. Harden verifier execution.
12. Run acceptance tests.
13. Only then update doctrine.

## Current Doctrine

non-autonomous by design

## Target Doctrine After Level 2A Tests

operator-governed, fail-closed, autonomy-gated, scalable, transferable, and AI-built
